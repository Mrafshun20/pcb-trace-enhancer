import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <iframe
      className="studio-frame"
      title="تریس — تقویت ترک برد"
      src="/enhancer.html"
      allow="camera; microphone; clipboard-write"
    />
  );
}
