import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BpuyvqBa.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
		className: "studio-frame",
		title: "تریس — تقویت ترک برد",
		src: "/enhancer.html",
		allow: "camera; microphone; clipboard-write"
	});
}
//#endregion
export { Home as component };
